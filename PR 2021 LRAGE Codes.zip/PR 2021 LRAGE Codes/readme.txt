LRAGE Matlab Code

This package contains the source code for the following paper:

	Jianglin Lu, Hailing Wang, Jie Zhou, Yudong Chen, Zhihui Lai, Qinghua Hu,
    	Low-Rank Adaptive Graph Embedding for Unsupervised Feature Extraction, Pattern Recognition, 2021
    	https://doi.org/10.1016/j.patcog.2020.107758

If you have any questions, please contact:

   	Jianglin Lu (jianglinlu@outlook.com)
